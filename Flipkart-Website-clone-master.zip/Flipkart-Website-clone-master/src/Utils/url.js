export const base_url = `https://click-cart-api.onrender.com`;
