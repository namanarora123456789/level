export const REQUEST = "cart/reuest";
export const ERROR = "cart/error";
export const POST_SUCCESS = "post/cart/success";
export const PATCH_SUCCESS = "patch/cart/success";
export const GET_SUCCESS = "get/cart/success";
export const DELETE_SUCCESS = "delete/cart/success";
