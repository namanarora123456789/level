export const REQUEST = "favourite/reuest";
export const ERROR = "favourite/error";
export const GET_SUCCESS = "favourite/success";
export const POST_SUCCESS = "favourite/success";
export const HANDLE_PAGE_CHANGE = "favourite/handlePageChange";
