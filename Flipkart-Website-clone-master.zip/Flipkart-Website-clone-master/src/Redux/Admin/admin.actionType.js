export const REQUEST = "search/reuest";
export const ERROR = "search/error";
export const GET_SUCCESS = "search/success";
export const HANDLE_PAGE_CHANGE = "search/handlePageChange";
